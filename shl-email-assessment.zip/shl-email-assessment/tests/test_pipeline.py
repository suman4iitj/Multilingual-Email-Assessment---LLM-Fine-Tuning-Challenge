"""End-to-end smoke test of predict.run() with a tiny random encoder and a fake judge (no downloads, runs on CPU).
It checks the plumbing (encoder -> judge cache -> combination -> output columns), not accuracy. Run: python tests/test_pipeline.py"""
import os, sys, tempfile
import numpy as np, pandas as pd, torch
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
os.environ["SHL_OUT"] = tempfile.mkdtemp()
from tokenizers import Tokenizer, models, trainers, pre_tokenizers
from transformers import PreTrainedTokenizerFast, BertConfig
import config, judge, predict
from model import MultiTaskModel

texts = [("Dzień dobry. Piszę w sprawie awarii. " * (1 + i % 5)).strip() for i in range(60)]
df = pd.DataFrame({"questionStatement": "Napisz e-mail.", "text": texts, "language": "Polish"})

d = tempfile.mkdtemp()
t = Tokenizer(models.WordPiece(unk_token="[UNK]")); t.pre_tokenizer = pre_tokenizers.Whitespace()
t.train_from_iterator(texts, trainers.WordPieceTrainer(vocab_size=200, special_tokens=["[PAD]", "[UNK]", "[CLS]", "[SEP]"]))
tk = PreTrainedTokenizerFast(tokenizer_object=t, pad_token="[PAD]", unk_token="[UNK]", cls_token="[CLS]", sep_token="[SEP]")
cfg = BertConfig(vocab_size=len(tk), hidden_size=32, num_hidden_layers=2, num_attention_heads=2, intermediate_size=64, max_position_embeddings=600)
m = MultiTaskModel(config=cfg); tk.save_pretrained(d); cfg.save_pretrained(d); torch.save(m.state_dict(), os.path.join(d, "weights.pt"))

calls = []
def fake_scores(name, dfs, bs=8):                      # stands in for the 14B judges
    calls.append(name); r = np.random.RandomState(len(calls)); out = {}
    for k, df_ in dfs.items():
        for v in range(config.N_VARIANTS):
            for key, (_, _, digits) in judge.RUBRIC.items(): out[f"{k}|{v}|{key}"] = list(r.uniform(min(digits), max(digits), len(df_)))
    return out
judge.judge_model_scores = fake_scores

cache = os.path.join(d, "cache.json")
pred, rec = predict.run(df, d, cache_path=cache)
assert list(pred.columns) == ["grammar", "content", "cefr", "cefr_idx", "cefr_expected"] and len(pred) == len(df)
assert pred.grammar.between(0, 5).all() and pred.content.between(0, 4).all() and set(pred.cefr) <= set(config.CEFR)
n_calls = len(calls); pred2, _ = predict.run(df, d, cache_path=cache, stats=rec)
assert len(calls) == n_calls, "second run must use the judge cache"
assert np.allclose(pred.grammar, pred2.grammar) and (pred.cefr == pred2.cefr).all()
enc_only, _ = predict.run(df, d, encoder_only=True); assert len(enc_only) == len(df)
print("pipeline smoke test passed;", len(config.JUDGES), "judges called once each:", calls)
