"""Unit tests for the combination step (no GPU, no model downloads). Run: python -m pytest tests -q"""
import os, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from combine import combine, log_words

rng = np.random.RandomState(0)
N = 120
TEXTS = ["palabra " * int(k) for k in rng.randint(5, 150, N)]
ENC = pd.DataFrame({"grammar": np.clip(3.4 + rng.randn(N), 0, 5), "content": np.clip(2.4 + .8 * rng.randn(N), 0, 4), "cefr_expected": np.clip(2.6 + rng.randn(N), 0, 5)})
J = {"grammar": 3.5 + rng.randn(N), "content": 2.5 + .8 * rng.randn(N), "cefr": np.clip(2.6 + rng.randn(N), 0, 5)}


def reference(wj, len_w):
    """Straight transcription of the formulas in the documentation."""
    zs = lambda x: (np.asarray(x, float) - np.mean(x)) / (np.std(x) + 1e-9)
    g = (1 - wj) * zs(ENC.grammar) + wj * zs(J["grammar"]); c = (1 - wj) * zs(ENC.content) + wj * zs(J["content"])
    if len_w: c = (1 - len_w) * zs(c) + len_w * zs(log_words(TEXTS))
    cd = (1 - wj) * ENC.cefr_expected.values + wj * J["cefr"]
    cf = cd.mean() + cd.std() * zs(0.5 * zs(cd) + 0.25 * zs(g) + 0.25 * zs(c))
    return np.clip(ENC.grammar.mean() + ENC.grammar.std() * zs(g), 0, 5), np.clip(ENC.content.mean() + ENC.content.std() * zs(c), 0, 4), cf


def test_matches_reference():
    for wj, lw in [(.7, .2), (.5, 0), (.5, .2), (.7, 0)]:
        out, _ = combine(ENC, J, TEXTS, wj, lw); g, c, cf = reference(wj, lw)
        assert np.allclose(out.grammar, g) and np.allclose(out.content, c) and np.allclose(out.cefr_expected, cf)


def test_frozen_stats_reproduce_batch():
    out, rec = combine(ENC, J, TEXTS); out2, _ = combine(ENC, J, TEXTS, stats=rec)
    assert all(np.allclose(out[c], out2[c]) for c in out.columns)
    one, _ = combine(ENC.iloc[:1], {k: v[:1] for k, v in J.items()}, TEXTS[:1], stats=rec)      # a single email works with frozen statistics
    assert np.isclose(one.grammar.iloc[0], out.grammar.iloc[0]) and one.cefr_idx.iloc[0] == out.cefr_idx.iloc[0]


def test_ranges():
    out, _ = combine(ENC, J, TEXTS)
    assert out.grammar.between(0, 5).all() and out.content.between(0, 4).all() and out.cefr_idx.between(0, 5).all()


if __name__ == "__main__":
    test_matches_reference(); test_frozen_stats_reproduce_batch(); test_ranges(); print("combine tests passed")
