# Training data

`train_synthetic.csv` holds the 2,927 synthetic training emails (2,500 generated, 294 with rule-based corruption, 133 truncated).

| column | meaning |
|---|---|
| language | Polish, Italian, Greek, Dutch or Portuguese |
| scenario_id | index of the task scenario (0-23), used for the grouped validation split |
| cefr_target, cefr_target_idx | CEFR level the generator was asked to imitate (A1..C2, 0..5) |
| grammar_target, content_target | grammar (0-5) and content (0-4) score the generator was asked to imitate |
| points_covered | how many of the 5 required points the email was told to cover |
| questionStatement | the task text in the email's language (translated by the generator model) |
| text | the email |
| grammar, content, cefr_idx | training labels (equal to the targets, shifted for augmented rows) |
| aug | none, corrupt (typos/missing accents/dropped words) or truncate |

All scenarios were written by me. None comes from the held-out test file, and no test text or label was used to write them.

## Public real data (not included)

The real learner texts used for the CEFR head come from [UniversalCEFR](https://huggingface.co/UniversalCEFR) and are not redistributed here,
because several corpora are licensed for non-commercial use only. `src/data_real.py` downloads them and rebuilds the exact rows and the real held-out split (seed 42).

| corpus | language | rows in training / held out | licence (as stated in the dataset) |
|---|---|---|---|
| merlin_it | Italian | 335 / 65 | CC BY-SA 4.0 |
| cople2_pt | Portuguese | 258 / 42 | CC BY-NC-SA 4.0 |
| peapl2_pt | Portuguese | 172 / 28 | CC BY-NC-SA 4.0 |
| elg_cefr_nl | Dutch | 127 / 23 | CC BY-NC-SA 4.0 |

These rows carry a CEFR label only. Their grammar and content loss is masked during training. There is no public Polish or Greek set in this collection.

## Rows per language in the training data

| language | synthetic rows | real rows (CEFR label only) |
|---|---|---|
| Dutch | 582 | 127 |
| Greek | 591 | 0 |
| Italian | 594 | 335 |
| Polish | 582 | 0 |
| Portuguese | 578 | 430 |
| total | 2,927 | 892 |

Polish and Greek rely on synthetic emails and on the zero-shot judges only.
