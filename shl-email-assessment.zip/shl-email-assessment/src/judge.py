"""Zero-shot LLM rubric judges. Each judge reads the official grammar / content / CEFR rubric and the email, and the score is
the expected value over the answer digits (probabilities of the tokens "0".."5"), so nothing is generated and nothing is trained."""
import os, gc, json
import numpy as np, torch
from config import *

RUBRIC = {
 "grammar": ("grammar quality, scale 0-5", """0: off topic, copies the prompt, or has fewer than 3 sentences.
1: many sentence fragments; several severe spelling/grammar errors; hard to understand.
2: few fragments but major spelling/grammar errors that sometimes muddle the meaning.
3: properly structured sentences but observable errors; unpolished.
4: all sentences well structured; only small slips that do not cause ambiguity.
5: few to no errors; nothing detracts from the purpose.""", range(0, 6)),
 "content": ("content quality, scale 0-4", """0: little or no effort; omits critical information, imitates the prompt, or is very short/off topic.
1: briefly mentions the purpose in a few lines but gives no details.
2: states the purpose and gives details, but some critical information is missing.
3: states the purpose and gives almost all required information; only minor details missing.
4: complete: clear purpose and all required information.""", range(0, 5)),
 "cefr": ("writing proficiency (CEFR) in the language of the email, scale 1-6", """1 = A1: very basic isolated phrases, fragmented, poorly structured.
2 = A2: simple sentences with simple connectors, frequent errors, basic structure.
3 = B1: some detail, organised, basic cohesion; errors do not impede understanding.
4 = B2: clear, well-structured, detailed; varied cohesive devices; occasional errors.
5 = C1: highly organised, extensive vocabulary incl. idioms, complex structures, high accuracy.
6 = C2: polished, precise and nuanced vocabulary, seamless flow, near-flawless.""", range(1, 7)),
}

def judge_prompt(r, key, v):
    title, rub, _ = RUBRIC[key]; lang = getattr(r, "language", "foreign-language")
    if v == 0:
        return (f"You are an expert examiner of written {lang} emails.\nTASK GIVEN TO THE CANDIDATE:\n{r.questionStatement}\n\n"
                f"CANDIDATE'S EMAIL:\n\"\"\"\n{r.text}\n\"\"\"\n\nRate the {title}.\n{rub}\nReply with only the single digit.")
    return (f"Scoring guide - {title}:\n{rub}\n\nYou are a strict, well-calibrated language examiner who has marked thousands of {lang} learner emails. "
            f"Use the whole scale; do not default to the middle.\n\nTask: {r.questionStatement}\n\nEmail written by the candidate:\n\"\"\"\n{r.text}\n\"\"\"\n\n"
            f"Give the {title} as a single digit and nothing else.")

@torch.no_grad()
def judge_model_scores(name, dfs, bs=8):
    """All (dataset, variant, key) scores of one judge model; model is freed afterwards."""
    from transformers import AutoTokenizer, AutoModelForCausalLM
    tok_j = AutoTokenizer.from_pretrained(name, padding_side="left")
    m = AutoModelForCausalLM.from_pretrained(name, torch_dtype=torch.bfloat16, device_map="auto").eval(); res = {}
    for dname, df in dfs.items():
        rs = list(df.itertuples())
        for v in range(N_VARIANTS):
            for key, (title, rub, digits) in RUBRIC.items():
                ids = [tok_j.encode(str(d), add_special_tokens=False)[0] for d in digits]; w = torch.tensor(list(digits), dtype=torch.float32)
                prompts = [tok_j.apply_chat_template([{"role": "user", "content": judge_prompt(r, key, v)}], tokenize=False, add_generation_prompt=True, enable_thinking=False) for r in rs]
                order = sorted(range(len(prompts)), key=lambda i: len(prompts[i])); vals = [None]*len(prompts); s, b = 0, bs
                while s < len(order):
                    idx = order[s:s+b]
                    try:
                        enc = tok_j([prompts[i] for i in idx], return_tensors="pt", padding=True).to(m.device)
                        h = m.model(**enc).last_hidden_state[:, -1]                    # last position only (saves memory)
                        p = torch.softmax(m.lm_head(h)[:, ids].float(), dim=-1).cpu(); e = (p * w).sum(-1).tolist()
                    except torch.cuda.OutOfMemoryError:
                        gc.collect(); torch.cuda.empty_cache(); b = max(1, b // 2); print("OOM -> judge batch", b, flush=True); continue
                    for j, i in enumerate(idx): vals[i] = e[j]
                    s += len(idx)
                res[f"{dname}|{v}|{key}"] = vals
        print("  judged with", name, flush=True)
    del m; gc.collect(); torch.cuda.empty_cache()
    return res

def get_judge_cache(dfs, cache_path, judges=None, reuse_path=None):
    """Judge scores per model, cached on disk. `dfs` maps a dataset id to a DataFrame; a cached entry is reused only
    if it covers the same dataset id and length (predict.py uses a content hash as the id)."""
    judges = judges or JUDGES
    if not os.path.exists(cache_path) and reuse_path and os.path.exists(reuse_path):
        old = json.load(open(reuse_path)); json.dump({n: v for n, v in old.items() if n in judges}, open(cache_path, "w")); print("reusing cached judge scores for", [n for n in old if n in judges])
    cache = json.load(open(cache_path)) if os.path.exists(cache_path) else {}
    for name in judges:
        have = cache.get(name, {}); need = {k: d for k, d in dfs.items() if f"{k}|{N_VARIANTS-1}|cefr" not in have or len(have[f"{k}|0|cefr"]) != len(d)}
        if need:
            have.update(judge_model_scores(name, need)); cache[name] = have; json.dump(cache, open(cache_path, "w"))
    return cache

def judge_signal(cache, dname, models=None):
    """Mean over judge models x prompt variants, per key; CEFR on the 0-5 index scale."""
    out = {}
    for key in RUBRIC:
        arr = np.mean([cache[n][f"{dname}|{v}|{key}"] for n in (models or JUDGES) for v in range(N_VARIANTS)], axis=0)
        out[key] = arr - 1 if key == "cefr" else arr
    return out
