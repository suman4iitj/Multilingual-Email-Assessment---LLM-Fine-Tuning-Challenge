"""Synthetic training data: scenarios, label design, LLM generation and rule-based augmentation.
Run:  python src/data_synthetic.py --out data/train_synthetic.csv
The code below is the notebook code, unchanged apart from imports."""
import re, json, time, random, gc, unicodedata, argparse
import numpy as np, pandas as pd, torch
from config import *

SCENARIOS = [
 ("You work in customer support at an online electronics shop. A customer, Mr. Novak, wrote that his laptop arrived with a cracked screen.",
  ["apologise for the damage", "offer a free replacement or full refund", "ask for photos of the damaged item", "say the courier will collect the laptop within 3 days", "give the support phone number and opening hours"]),
 ("You are an office manager. You must tell all staff that the office will be closed next Friday for maintenance.",
  ["state the exact date of the closure", "explain that the air-conditioning is being replaced", "say that everyone should work from home", "ask staff to take their laptops and chargers home", "give a contact person for urgent matters"]),
 ("You are a student. You want to ask Professor Rossi for an extension on your final essay because you were ill.",
  ["introduce yourself and your course", "explain that you were ill for a week", "propose a new deadline", "offer to send a doctor's note", "thank the professor"]),
 ("You are an HR assistant. Write to a candidate, Ms. Costa, to invite her to a job interview.",
  ["name the position she applied for", "give the interview date and time", "give the office address and how to get there", "list the documents she should bring", "ask her to confirm attendance by Wednesday"]),
 ("You manage a small hotel. A guest complained that the room was noisy and the breakfast was cold.",
  ["apologise sincerely", "explain that there was construction nearby", "offer a free night or a discount", "describe changes to the breakfast service", "invite the guest to return"]),
 ("You are a project coordinator. You must postpone a team meeting scheduled for Monday.",
  ["say the meeting is postponed", "explain that the client moved their deadline", "propose two new dates", "ask for availability by tomorrow", "attach or mention the updated agenda"]),
 ("You are a tenant. Write to your landlord about a broken heating system.",
  ["describe the problem and when it started", "say you already tried restarting it", "mention that the weather is very cold", "ask for a technician visit this week", "offer times when you are at home"]),
 ("You work at a language school. Inform a parent that their child's class schedule has changed.",
  ["state the new day and time", "explain that the teacher is changing", "say the content of the course stays the same", "offer a trial lesson with the new teacher", "ask the parent to reply if the time is a problem"]),
 ("You are a sales representative. Follow up with a potential client after a product demonstration.",
  ["thank the client for their time", "summarise two main benefits of the product", "mention a 10% discount valid until the end of the month", "offer a free trial", "propose a follow-up call next week"]),
 ("You organise a charity run. Write to volunteers with information about the event.",
  ["give the date, time and place", "explain the volunteers' tasks", "say that lunch is provided", "ask them to wear the orange T-shirt", "give the organiser's phone number"]),
 ("You are an IT technician. Tell employees about a security update to their computers.",
  ["say all computers must be updated by Thursday", "explain it protects against viruses", "say the update takes about 30 minutes", "tell them to save their work first", "tell them to contact the helpdesk if problems occur"]),
 ("You bought a pair of shoes online and the wrong size arrived. Write to the seller.",
  ["give your order number", "say which size you ordered and which arrived", "ask for an exchange, not a refund", "ask who pays the return shipping", "say you need them before your trip on the 20th"]),
 ("You are a restaurant owner. Reply to a customer who wants to book a table for a birthday party of twelve.",
  ["confirm availability on the requested Saturday", "say a deposit of 50 euros is needed", "describe the set menu options", "ask about allergies or dietary needs", "offer to decorate the table"]),
 ("You are a team leader. Congratulate a colleague, Anna, on her promotion and invite the team to celebrate.",
  ["congratulate Anna and name her new role", "mention one of her achievements", "give the date and place of the celebration", "say that the company will pay for drinks", "ask colleagues to confirm attendance"]),
 ("You are a librarian. Write to a member whose borrowed books are overdue.",
  ["name the books and the due date", "state the late fee per day", "ask the member to return the books by Friday", "explain that fees can be waived once", "mention the library opening hours"]),
 ("You are a gym manager. Announce new classes and a price change to members.",
  ["announce yoga and spinning classes", "give the schedule of the new classes", "state the new monthly price", "explain the price applies from next month", "invite members to a free first session"]),
 ("You are a travel agent. Send a customer the details of the holiday package he asked about.",
  ["name the destination and the dates", "state the total price", "describe what is included (flight, hotel, breakfast)", "mention the cancellation policy", "ask for a 20% deposit to confirm"]),
 ("You are a school secretary. Tell parents about a school trip to a science museum.",
  ["give the date and departure time", "state the cost per student", "ask for a signed permission form", "tell them to send a packed lunch", "give the teacher's contact details"]),
 ("You are a supplier. Inform a client that their order will be delayed.",
  ["say the order will be late and by how long", "explain the delay was caused by a strike at the port", "apologise", "offer free delivery as compensation", "promise a tracking number by tomorrow"]),
 ("You are a neighbour. Write to the residents' association about loud construction at night.",
  ["describe the noise and its hours", "say it has lasted two weeks", "mention that it affects children and sleep", "ask the association to speak to the company", "propose a meeting"]),
 ("You are a freelancer. Send a client your invoice and a project update.",
  ["say the invoice is attached", "give the payment deadline", "report that the website design is 80% finished", "name one remaining task", "ask for feedback on the design"]),
 ("You are a doctor's receptionist. Remind a patient of an appointment and explain preparation.",
  ["state the date, time and doctor", "ask the patient not to eat for 8 hours before", "ask to bring previous test results", "explain how to cancel or reschedule", "give the clinic address"]),
 ("You are a conference organiser. Invite a researcher to give a keynote talk.",
  ["name the conference, date and city", "explain why you chose this researcher", "say the talk should last 45 minutes", "offer travel and hotel costs", "ask for an answer within two weeks"]),
 ("You are a bank clerk. Inform a customer that a suspicious transaction was blocked on their card.",
  ["describe the blocked transaction (amount and place)", "say the card has been temporarily blocked", "ask the customer to confirm if it was theirs", "explain that a new card will arrive in 5 days", "give the fraud hotline number"]),
]

GRAMMAR_STYLE = {
 0: "The email is off-topic or just copies the task wording or is under 3 sentences.",
 1: "Many sentence fragments (missing subject or verb), several severe spelling and grammar errors; meaning is hard to understand.",
 2: "Few fragments but MAJOR spelling/grammar errors (wrong verb forms, agreement, word order, cases) that sometimes muddle the meaning.",
 3: "Sentences are properly structured but there are observable spelling/grammar errors (articles, prepositions, agreement, wrong word choice) that make the text unpolished.",
 4: "All sentences well structured; only some small spelling or grammar slips (a few missing accents/commas, an occasional wrong preposition) that do not cause ambiguity.",
 5: "Essentially flawless grammar and spelling.",
}
LEVEL_STYLE = {
 "A1": "very basic isolated phrases, tiny vocabulary, repetitive, very short, poorly connected",
 "A2": "simple short sentences joined by 'and/but/because', basic vocabulary, basic opening and closing",
 "B1": "some detail and explanation, basic connectors, mostly simple sentences with a few complex ones",
 "B2": "clear, well organised, variety of connectors, broad vocabulary, some complex structures",
 "C1": "highly organised, sophisticated connectors, extensive/varied vocabulary incl. idioms, complex structures used naturally",
 "C2": "polished and nuanced, seamless transitions, precise idiomatic/professional vocabulary, effortless tone adaptation",
}
G_GIVEN_LEVEL = {  # P(grammar | CEFR level)
 "A1": {0:.12, 1:.50, 2:.38}, "A2": {1:.25, 2:.50, 3:.25}, "B1": {2:.25, 3:.50, 4:.25},
 "B2": {3:.35, 4:.45, 5:.20}, "C1": {3:.10, 4:.45, 5:.45}, "C2": {4:.25, 5:.75}}
POINTS_FOR_CONTENT = {0: 0, 1: 1, 2: 3, 3: 4, 4: 5}
CONTENT_STYLE = {
 0: "Show little effort: write only 1-2 vague lines that do not give any of the required information.",
 1: "Briefly mention the purpose in a few lines but give NO details.",
 2: "State the purpose and give details, but leave out some important required points.",
 3: "State the purpose and cover almost everything; only minor details are missing.",
 4: "Complete: clear purpose and every required point covered.",
}
def sample_spec(lang, i):
    lvl = CEFR[i % 6] if random.random() < .7 else random.choice(CEFR)
    li = CEFR.index(lvl)
    g = int(np.random.choice(list(G_GIVEN_LEVEL[lvl]), p=list(G_GIVEN_LEVEL[lvl].values())))
    c = int(np.clip(round(np.random.normal(1.0 + 0.5*li, 0.9)), 0, 4))
    sid = random.randrange(len(SCENARIOS))
    return dict(language=lang, scenario_id=sid, cefr_target=lvl, grammar_target=g, content_target=c)

import gc

def load_llm(name=None):
    from transformers import AutoTokenizer, AutoModelForCausalLM
    tok = AutoTokenizer.from_pretrained(name or GEN_MODEL, padding_side="left")
    m = AutoModelForCausalLM.from_pretrained(name or GEN_MODEL, torch_dtype=torch.bfloat16, device_map="auto")  # ~15 GB for 7B
    return tok, m.eval()

_LLM = {}
@torch.no_grad()
def llm_generate(prompts, max_new_tokens=450, bs=32, temperature=0.8, sample=True):
    if "m" not in _LLM: _LLM["tok"], _LLM["m"] = load_llm()
    tok, m = _LLM["tok"], _LLM["m"]
    order = sorted(range(len(prompts)), key=lambda i: len(prompts[i])); res = [None]*len(prompts)
    s = 0
    while s < len(order):
        idx = order[s:s+bs]
        texts = [tok.apply_chat_template([{"role":"user","content":prompts[i]}], tokenize=False, add_generation_prompt=True) for i in idx]
        enc = tok(texts, return_tensors="pt", padding=True).to(m.device)
        try:
            out = m.generate(**enc, max_new_tokens=max_new_tokens, do_sample=sample, temperature=temperature if sample else None,
                             top_p=0.95 if sample else None, pad_token_id=tok.pad_token_id or tok.eos_token_id)
        except torch.cuda.OutOfMemoryError:
            del enc; gc.collect(); torch.cuda.empty_cache(); bs = max(1, bs // 2); print("OOM -> batch size", bs, flush=True); continue
        for j, i in enumerate(idx):
            res[i] = tok.decode(out[j, enc.input_ids.shape[1]:], skip_special_tokens=True).strip()
        s += len(idx); del out, enc; torch.cuda.empty_cache()
        if (s // max(bs, 1)) % 10 == 0: print(f"  generated {s}/{len(prompts)}", flush=True)
    return res

def norm(t):  # keep all scripts intact: NFC, no lossy ascii folding
    return unicodedata.normalize("NFC", t).replace("\r\n", "\n").strip()

def build_statements():
    """Question statement per (scenario, language), translated by the LLM."""
    keys, prompts = [], []
    for sid, (ctx, pts) in enumerate(SCENARIOS):
        en = ctx + " In your email: " + "; ".join(pts) + "."
        for lang in LANGS:
            keys.append((sid, lang))
            prompts.append(f"Translate this exam task into {lang}. Address the candidate directly (second person, formal). Keep every detail. Output only the {lang} text.\n\n{en}")
    outs = llm_generate(prompts, max_new_tokens=300, bs=16, sample=False)
    return {k: norm(o) for k, o in zip(keys, outs)}

def email_prompt(sp):
    ctx, pts = SCENARIOS[sp["scenario_id"]]
    k = POINTS_FOR_CONTENT[sp["content_target"]]
    chosen = sorted(random.sample(range(5), k)); sp["points_covered"] = k
    req = "\n".join(f"- {pts[i]}" for i in chosen) if chosen else "(none)"
    return (f"You are simulating a candidate in a writing exam. Write ONLY the email, in {sp['language']}, no explanations, no translation, no notes.\n"
            f"TASK GIVEN TO THE CANDIDATE: {ctx}\n"
            f"CEFR level of the candidate in {sp['language']}: {sp['cefr_target']} ({LEVEL_STYLE[sp['cefr_target']]}).\n"
            f"GRAMMAR QUALITY: {GRAMMAR_STYLE[sp['grammar_target']]} Make the errors natural, like a real learner, never flag them.\n"
            f"CONTENT: {CONTENT_STYLE[sp['content_target']]}\nPoints you must include (and no others):\n{req}\n"
            f"Length should fit the level. Include a greeting and closing unless the grammar style says otherwise.")

JUDGE = """You are a strict examiner. Score the candidate email (written in {lang}) for the task below.
TASK: {ctx}  REQUIRED POINTS: {pts}
Grammar 0-5: 0 off-topic/copies prompt/<3 sentences; 1 many fragments + severe errors; 2 few fragments but major errors muddling meaning; 3 well-structured but observable errors, unpolished; 4 only small slips, no ambiguity; 5 few to no errors.
Content 0-4: 0 little/no effort; 1 purpose mentioned briefly, no details; 2 purpose + details but critical info missing; 3 almost all info, minor details missing; 4 complete.
CEFR: A1..C2 writing proficiency in {lang}.
EMAIL:
\"\"\"{email}\"\"\"
Return JSON only: {{"grammar": int, "content": int, "cefr": "B1"}}"""

def parse_judge(s):
    try:
        j = json.loads(re.search(r"\{.*?\}", s, re.S).group(0))
        return float(j["grammar"]), float(j["content"]), CEFR.index(str(j["cefr"]).strip().upper())
    except Exception:
        return None

def make_dataset():
    t0 = time.time()
    stm = build_statements()
    specs = [sample_spec(l, i) for l in LANGS for i in range(N_PER_LANG)]
    prompts = [email_prompt(s) for s in specs]
    emails = llm_generate(prompts, max_new_tokens=450)
    rows = []
    for sp, e in zip(specs, emails):
        e = norm(e)
        if len(e) < 10 or re.search(r"as an ai|language model", e, re.I): continue
        rows.append({**sp, "questionStatement": stm[(sp["scenario_id"], sp["language"])], "text": e})
    df = pd.DataFrame(rows)
    df["cefr_target_idx"] = df.cefr_target.map(CEFR.index)
    if USE_JUDGE:
        jp = [JUDGE.format(lang=r.language, ctx=SCENARIOS[r.scenario_id][0], pts="; ".join(SCENARIOS[r.scenario_id][1]), email=r.text) for r in df.itertuples()]
        js = [parse_judge(o) for o in llm_generate(jp, max_new_tokens=40, bs=16, sample=False)]
        df["jg"] = [j[0] if j else np.nan for j in js]; df["jc"] = [j[1] if j else np.nan for j in js]
        df["jl"] = [j[2] if j else np.nan for j in js]
        ok = df.jg.notna() & ((df.jg-df.grammar_target).abs() <= 1) & ((df.jc-df.content_target).abs() <= 1) & ((df.jl-df.cefr_target_idx).abs() <= 2)
        print(f"judge kept {ok.sum()}/{len(df)}"); df = df[ok].copy()
        df["grammar"] = (df.grammar_target + df.jg) / 2; df["content"] = (df.content_target + df.jc) / 2
        df["cefr_idx"] = ((df.cefr_target_idx*2 + df.jl) / 3).round().astype(int)
    else:
        df["grammar"], df["content"], df["cefr_idx"] = df.grammar_target, df.content_target, df.cefr_target_idx
    print(f"data synthesis took {(time.time()-t0)/60:.1f} min"); return df.reset_index(drop=True)

def strip_marks(s): return unicodedata.normalize("NFC", "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn"))
def corrupt(text, rate):
    out = []
    for w in text.split(" "):
        r = random.random()
        if len(w) > 3 and r < rate:
            i = random.randrange(len(w)-1); op = random.choice(["swap", "del", "dup"])
            w = w[:i]+w[i+1]+w[i]+w[i+2:] if op == "swap" else (w[:i]+w[i+1:] if op == "del" else w[:i]+w[i]+w[i:])
        elif r > 1 - rate/3: continue            # drop word
        out.append(w)
    return " ".join(out)
def augment(df, frac=0.25):
    new = []
    for r in df[df.grammar >= 3.5].sample(frac=frac, random_state=SEED).itertuples():
        sev = random.choice([1, 2])
        t = corrupt(r.text, .08*sev + .04)
        if random.random() < .5: t = strip_marks(t)
        d = r._asdict(); d.update(text=t, grammar=max(0.0, r.grammar - sev*0.9), cefr_idx=max(0, r.cefr_idx - (1 if sev == 2 else 0)), aug="corrupt"); new.append(d)
    for r in df[df.content >= 2.5].sample(frac=frac/2, random_state=SEED+1).itertuples():
        sents = re.split(r"(?<=[.!?])\s+", r.text); keep = max(2, int(len(sents)*random.choice([.3, .5])))
        d = r._asdict(); d.update(text=" ".join(sents[:keep]), content=max(0.0, r.content - 1.5), aug="truncate"); new.append(d)
    out = pd.concat([df.assign(aug="none"), pd.DataFrame(new).drop(columns=["Index"], errors="ignore")], ignore_index=True)
    return out

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="data/train_synthetic.csv")
    a = ap.parse_args(); seed_everything()
    df = augment(make_dataset())
    df.to_csv(a.out, index=False, encoding="utf-8-sig"); print("saved", df.shape, "->", a.out)
