"""Fine-tune the multitask XLM-R encoder (grammar and content regression, ordinal CEFR head).
Run:  python src/train_encoder.py --train data/train_synthetic.csv [--no_real]
The training function is the notebook code, unchanged apart from imports."""
from config import *
import os, json, argparse
import numpy as np, pandas as pd, torch
from scipy.stats import pearsonr
from transformers import AutoTokenizer, AutoConfig, get_linear_schedule_with_warmup
from torch.optim.swa_utils import AveragedModel, get_ema_multi_avg_fn
from model import MultiTaskModel, decode, G_MAX, C_MAX
import torch.nn.functional as F

REG_W, LLRD, EMA_DECAY = 4.0, 0.9, 0.98                # MSE tracks Pearson; REG_W balances regression vs the CEFR BCE term
AMP = torch.bfloat16 if (DEVICE == "cuda" and torch.cuda.is_bf16_supported()) else torch.float16

def get_tok_and_model():
    return AutoTokenizer.from_pretrained(BACKBONE), MultiTaskModel(BACKBONE)

class DS(torch.utils.data.Dataset):
    def __init__(self, df, tok):
        self.q = df.questionStatement.fillna("").tolist(); self.t = df.text.tolist(); self.tok = tok
        self.y = np.stack([df.grammar/G_MAX, df.content/C_MAX, df.cefr_idx], 1).astype("float32") if "grammar" in df else None   # NaN = no label
    def __len__(self): return len(self.t)
    def __getitem__(self, i): return i
    def collate(self, idx):
        enc = self.tok([self.q[i] for i in idx], [self.t[i] for i in idx], truncation=True, max_length=MAX_LEN, padding=True, return_tensors="pt")
        if self.y is not None: enc["y"] = torch.tensor(self.y[idx])
        return enc

def loss_fn(out, y):
    g, c, lg = out
    ordinal_t = (y[:, 2:3] > torch.arange(5, device=y.device)).float()          # (B,5) cumulative CEFR targets
    loss = F.binary_cross_entropy_with_logits(lg.float(), ordinal_t)
    mg, mc = ~torch.isnan(y[:, 0]), ~torch.isnan(y[:, 1])                       # real rows carry no grammar/content label
    if mg.any(): loss = loss + REG_W * F.mse_loss(g[mg].float(), y[mg, 0])
    if mc.any(): loss = loss + REG_W * F.mse_loss(c[mc].float(), y[mc, 1])
    return loss

@torch.no_grad()
def run_eval(model, ds, bs=32):
    model.eval(); outs = []
    dl = torch.utils.data.DataLoader(ds, batch_size=bs, collate_fn=ds.collate)
    for b in dl:
        b = {k: v.to(DEVICE) for k, v in b.items() if k != "y"}
        with torch.autocast(DEVICE, dtype=AMP, enabled=DEVICE == "cuda"):
            outs.append(pd.DataFrame(decode(*model(**b))))
    return pd.concat(outs, ignore_index=True)

def metrics(pred, gold_g, gold_c, gold_l):
    return {"grammar_pearson": pearsonr(pred.grammar, gold_g)[0], "content_pearson": pearsonr(pred.content, gold_c)[0],
            "cefr_pearson": pearsonr(pred.cefr_idx, gold_l)[0], "cefr_pearson_expected": pearsonr(pred.cefr_expected, gold_l)[0],
            "cefr_exact": float((pred.cefr_idx.values == np.asarray(gold_l)).mean()), "cefr_within1": float((abs(pred.cefr_idx.values - np.asarray(gold_l)) <= 1).mean())}

def param_groups(model, lr, decay):
    """Layer-wise LR decay: top encoder layers learn fastest, embeddings slowest; heads learn 20x faster."""
    layers, n, seen, groups = model.enc.encoder.layer, len(model.enc.encoder.layer), set(), []
    def add(params, l):
        params = [p for p in params if id(p) not in seen]; seen.update(id(p) for p in params)
        if params: groups.append({"params": params, "lr": l})
    add(model.enc.embeddings.parameters(), lr * decay**n)
    for i, layer in enumerate(layers): add(layer.parameters(), lr * decay**(n-1-i))
    add([p for k, p in model.named_parameters() if k.startswith("enc.")], lr)
    add([p for k, p in model.named_parameters() if not k.startswith("enc.")], lr*20)
    return groups

def train(df, rh=None):
    torch.manual_seed(SEED)
    syn = df[df.scenario_id.astype(str) != "REAL"]
    sc = syn.scenario_id.unique(); rng = np.random.RandomState(SEED); rng.shuffle(sc)
    val_sc = set(sc[:max(2, int(.2*len(sc)))])
    tr, va = df[~df.scenario_id.isin(val_sc)], df[df.scenario_id.isin(val_sc) & (df.aug == "none")]     # real rows are always in train
    print("train", len(tr), "(real:", int((tr.scenario_id.astype(str) == "REAL").sum()), ") val", len(va), "val scenarios", sorted(val_sc))
    tok, model = get_tok_and_model(); model.to(DEVICE)
    ema = AveragedModel(model, multi_avg_fn=get_ema_multi_avg_fn(EMA_DECAY))
    dtr, dva = DS(tr.reset_index(drop=True), tok), DS(va.reset_index(drop=True), tok)
    dh = DS(rh, tok) if rh is not None else None
    dl = torch.utils.data.DataLoader(dtr, batch_size=BS, shuffle=True, collate_fn=dtr.collate)
    opt = torch.optim.AdamW(param_groups(model, LR, LLRD), weight_decay=.01)
    steps = EPOCHS*len(dl); sch = get_linear_schedule_with_warmup(opt, int(.1*steps), steps)
    scaler = torch.amp.GradScaler("cuda", enabled=(DEVICE == "cuda" and AMP == torch.float16)); best, hist = -1e9, []
    for ep in range(EPOCHS):
        model.train(); tl = 0
        for b in dl:
            b = {k: v.to(DEVICE) for k, v in b.items()}; y = b.pop("y")
            with torch.autocast(DEVICE, dtype=AMP, enabled=DEVICE == "cuda"):
                loss = loss_fn(model(**b), y)
            opt.zero_grad(set_to_none=True); scaler.scale(loss).backward(); scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); scaler.step(opt); scaler.update(); sch.step()
            ema.update_parameters(model); tl += loss.item()
        m = metrics(run_eval(ema.module, dva), va.grammar.values, va.content.values, va.cefr_idx.values)     # EMA weights
        score = float(np.nansum([m["grammar_pearson"], m["content_pearson"], m["cefr_pearson"]])) / 3
        if dh is not None:                                                  # REAL held-out CEFR: the only real-data signal during training
            pr = run_eval(ema.module, dh); m["real_cefr_r"] = pearsonr(pr.cefr_expected, rh.cefr_idx)[0]
            m["real_cefr_exact"] = float((pr.cefr_idx.values == rh.cefr_idx.values).mean()); score += float(np.nan_to_num(m["real_cefr_r"]))
        hist.append({"epoch": ep+1, "loss": tl/len(dl), **m})
        print(f"ep{ep+1} loss {tl/len(dl):.4f} " + " ".join(f"{k}={v:.3f}" for k, v in m.items()))
        if score > best:
            best = score; os.makedirs(f"{OUT}/model", exist_ok=True)
            torch.save(ema.module.state_dict(), f"{OUT}/model/weights.pt"); tok.save_pretrained(f"{OUT}/model"); ema.module.enc.config.save_pretrained(f"{OUT}/model")
    pd.DataFrame(hist).to_csv(f"{OUT}/val_history.csv", index=False); return tok, ema.module



if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", default="data/train_synthetic.csv"); ap.add_argument("--no_real", action="store_true")
    a = ap.parse_args(); seed_everything()
    train_df = pd.read_csv(a.train, encoding="utf-8").assign(source="synthetic", license="own"); real_hold = None
    if USE_REAL and not a.no_real:
        from data_real import load_real
        real_tr, real_hold = load_real()
        if real_tr is not None:
            train_df = pd.concat([train_df, real_tr], ignore_index=True)
            os.makedirs(OUT, exist_ok=True); real_hold.to_csv(f"{OUT}/real_holdout.csv", index=False, encoding="utf-8-sig")
    print(len(train_df), "training rows")
    tok, model = train(train_df, real_hold)
