"""Final combination of the fine-tuned encoder and the LLM judge ensemble.

Steps (all weights are fixed, nothing is fitted on labels):
  grammar : (1-W) * z(encoder) + W * z(judges)
  content : same blend, then (1-L) * z(blend) + L * z(log word count)
  CEFR    : level scale blend (1-W) * encoder + W * judges, then 0.5 z(level) + 0.25 z(grammar) + 0.25 z(content),
            mapped back onto the level scale; the CEFR class is the rounded value.
Standardisation uses the statistics of the batch being scored by default. For small batches or one-by-one use,
save the statistics once from a reference batch (`save_stats`) and pass them back as `stats`.
"""
import re
import numpy as np, pandas as pd

CEFR_LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"]


class Normaliser:
    """z-scores with batch statistics (stats=None) or with frozen statistics; every statistic is recorded by name."""
    def __init__(self, stats=None):
        self.stats, self.record = stats, {}

    def _get(self, name, x, ddof):
        x = np.asarray(x, dtype=float)
        if self.stats is not None: m, s = self.stats[name]
        else: m, s = float(np.mean(x)), float(np.std(x, ddof=ddof))
        self.record[name] = [m, s]; return m, s

    def z(self, name, x):
        m, s = self._get(name, x, 0); return (np.asarray(x, dtype=float) - m) / (s + 1e-9)

    def ref(self, name, x):
        """mean / sample std (ddof=1, as pandas) of the encoder's own predictions; used to map blended scores back to 0-5 / 0-4."""
        return self._get(name, x, 1)


def log_words(texts):
    return np.log1p(np.array([len(re.findall(r"\w+", t)) for t in texts], dtype=float))


def as_pred(g, c, ce):
    return pd.DataFrame({"grammar": g, "content": c, "cefr_expected": ce,
                         "cefr_idx": np.clip(np.rint(ce), 0, 5).astype(int)})


def combine(enc, J, texts, w_judge=0.70, len_w=0.20, stats=None):
    """enc: DataFrame with grammar, content, cefr_expected (encoder). J: dict grammar, content, cefr (judge ensemble, CEFR on 0-5).
    texts: the emails (for the length prior). Returns (prediction DataFrame, recorded statistics)."""
    N = Normaliser(stats); wj = w_judge
    g = (1 - wj) * N.z("enc_grammar", enc.grammar) + wj * N.z("judge_grammar", J["grammar"])
    c = (1 - wj) * N.z("enc_content", enc.content) + wj * N.z("judge_content", J["content"])
    if len_w: c = (1 - len_w) * N.z("blend_content", c) + len_w * N.z("log_words", log_words(texts))
    cd = (1 - wj) * np.asarray(enc.cefr_expected, dtype=float) + wj * np.asarray(J["cefr"], dtype=float)
    zg, zc, zcd = N.z("blend_grammar", g), N.z("blend_content_final", c), N.z("cefr_direct", cd)
    mix = 0.5 * zcd + 0.25 * zg + 0.25 * zc
    m, s = N.record["cefr_direct"]                       # mean / std of the direct level signal
    cf = m + s * N.z("cefr_mix", mix)
    mg, sg = N.ref("enc_grammar_ref", enc.grammar); mc, sc = N.ref("enc_content_ref", enc.content)
    grammar = np.clip(mg + sg * zg, 0, 5); content = np.clip(mc + sc * zc, 0, 4)
    return as_pred(grammar, content, cf), N.record
