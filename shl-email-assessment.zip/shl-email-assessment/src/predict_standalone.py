"""Standalone full pipeline: fine-tuned encoder (weights loaded from MODEL_DIR) + two zero-shot LLM judges + fixed-weight blend.
Reads an xlsx/csv with `text` (and `questionStatement`, `language`), writes predictions, and prints the assessment metrics when the file also has
gold columns `grammar`, `content`, `cefr`.  Usage:
  python predict_standalone.py --input test_dataset.xlsx --model_dir <folder with weights.pt> --output preds.csv --cache judge_cache.json
"""
import argparse, gc, hashlib, json, os, re, unicodedata
import numpy as np, pandas as pd, torch, torch.nn as nn
from scipy.stats import pearsonr
from transformers import AutoModel, AutoTokenizer, AutoConfig

# ---- settings used for the reported run ----
CEFR = ["A1", "A2", "B1", "B2", "C1", "C2"]
JUDGES = ["Qwen/Qwen2.5-14B-Instruct", "Qwen/Qwen3-14B"]      # ~30 GB each in bf16, loaded one after the other
N_VARIANTS = 2                                                # prompt wordings per judge
W_JUDGE, LEN_W = 0.70, 0.20                                   # blend weight of the judges; weight of the log-length prior on content
MAX_LEN = 512
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
SEED = 42


def norm(t):
    return unicodedata.normalize("NFC", t).replace("\r\n", "\n").strip()


# ================= encoder =================
CEFR_LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"]
G_MAX, C_MAX = 5.0, 4.0


class MultiTaskModel(nn.Module):
    def __init__(self, name=None, config=None, dropout=0.1):
        super().__init__()
        self.enc = AutoModel.from_pretrained(name) if config is None else AutoModel.from_config(config)
        h = self.enc.config.hidden_size
        self.drop = nn.Dropout(dropout)
        self.g_head = nn.Sequential(nn.Linear(h, h // 2), nn.GELU(), nn.Linear(h // 2, 1))
        self.c_head = nn.Sequential(nn.Linear(h, h // 2), nn.GELU(), nn.Linear(h // 2, 1))
        # CORAL-style ordinal head: one shared score + 5 ordered thresholds. Sees the pooled text
        # plus the (detached) grammar/content predictions as extra signals.
        self.cefr_fc = nn.Linear(h + 2, 1, bias=False)
        self.cefr_bias = nn.Parameter(torch.linspace(1.5, -1.5, 5))

    def forward(self, input_ids, attention_mask, **_):
        hs = self.enc(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        m = attention_mask.unsqueeze(-1).to(hs.dtype)
        pooled = self.drop((hs * m).sum(1) / m.sum(1).clamp(min=1))  # masked mean pooling
        g = self.g_head(pooled).squeeze(-1)   # normalised 0..1
        c = self.c_head(pooled).squeeze(-1)
        x = torch.cat([pooled, g.detach().unsqueeze(-1), c.detach().unsqueeze(-1)], -1)
        cefr_logits = self.cefr_fc(x) + self.cefr_bias  # (B,5): logit of P(level > k)
        return g, c, cefr_logits


def decode(g, c, cefr_logits):
    p = torch.sigmoid(cefr_logits.float())
    return {
        "grammar": (g.float().clamp(0, 1) * G_MAX).cpu().numpy(),
        "content": (c.float().clamp(0, 1) * C_MAX).cpu().numpy(),
        "cefr_idx": (p > 0.5).sum(1).cpu().numpy(),      # discrete level for exact match
        "cefr_expected": p.sum(1).cpu().numpy(),          # continuous level
    }


AMP = torch.bfloat16 if (DEVICE == "cuda" and torch.cuda.is_bf16_supported()) else torch.float16

class DS(torch.utils.data.Dataset):
    def __init__(self, df, tok):
        self.q = df.questionStatement.fillna("").tolist(); self.t = df.text.tolist(); self.tok = tok
        self.y = np.stack([df.grammar/G_MAX, df.content/C_MAX, df.cefr_idx], 1).astype("float32") if "grammar" in df else None   # NaN = no label
    def __len__(self): return len(self.t)
    def __getitem__(self, i): return i
    def collate(self, idx):
        enc = self.tok([self.q[i] for i in idx], [self.t[i] for i in idx], truncation=True, max_length=MAX_LEN, padding=True, return_tensors="pt")
        if self.y is not None: enc["y"] = torch.tensor(self.y[idx])
        return enc


@torch.no_grad()
def run_eval(model, ds, bs=32):
    model.eval(); outs = []
    dl = torch.utils.data.DataLoader(ds, batch_size=bs, collate_fn=ds.collate)
    for b in dl:
        b = {k: v.to(DEVICE) for k, v in b.items() if k != "y"}
        with torch.autocast(DEVICE, dtype=AMP, enabled=DEVICE == "cuda"):
            outs.append(pd.DataFrame(decode(*model(**b))))
    return pd.concat(outs, ignore_index=True)


# ================= LLM judges =================
import json
RUBRIC = {
 "grammar": ("grammar quality, scale 0-5", """0: off topic, copies the prompt, or has fewer than 3 sentences.
1: many sentence fragments; several severe spelling/grammar errors; hard to understand.
2: few fragments but major spelling/grammar errors that sometimes muddle the meaning.
3: properly structured sentences but observable errors; unpolished.
4: all sentences well structured; only small slips that do not cause ambiguity.
5: few to no errors; nothing detracts from the purpose.""", range(0, 6)),
 "content": ("content quality, scale 0-4", """0: little or no effort; omits critical information, imitates the prompt, or is very short/off topic.
1: briefly mentions the purpose in a few lines but gives no details.
2: states the purpose and gives details, but some critical information is missing.
3: states the purpose and gives almost all required information; only minor details missing.
4: complete: clear purpose and all required information.""", range(0, 5)),
 "cefr": ("writing proficiency (CEFR) in the language of the email, scale 1-6", """1 = A1: very basic isolated phrases, fragmented, poorly structured.
2 = A2: simple sentences with simple connectors, frequent errors, basic structure.
3 = B1: some detail, organised, basic cohesion; errors do not impede understanding.
4 = B2: clear, well-structured, detailed; varied cohesive devices; occasional errors.
5 = C1: highly organised, extensive vocabulary incl. idioms, complex structures, high accuracy.
6 = C2: polished, precise and nuanced vocabulary, seamless flow, near-flawless.""", range(1, 7)),
}

def judge_prompt(r, key, v):
    title, rub, _ = RUBRIC[key]; lang = getattr(r, "language", "foreign-language")
    if v == 0:
        return (f"You are an expert examiner of written {lang} emails.\nTASK GIVEN TO THE CANDIDATE:\n{r.questionStatement}\n\n"
                f"CANDIDATE'S EMAIL:\n\"\"\"\n{r.text}\n\"\"\"\n\nRate the {title}.\n{rub}\nReply with only the single digit.")
    return (f"Scoring guide - {title}:\n{rub}\n\nYou are a strict, well-calibrated language examiner who has marked thousands of {lang} learner emails. "
            f"Use the whole scale; do not default to the middle.\n\nTask: {r.questionStatement}\n\nEmail written by the candidate:\n\"\"\"\n{r.text}\n\"\"\"\n\n"
            f"Give the {title} as a single digit and nothing else.")

@torch.no_grad()
def judge_model_scores(name, dfs, bs=8):
    """All (dataset, variant, key) scores of one judge model; model is freed afterwards."""
    from transformers import AutoTokenizer, AutoModelForCausalLM
    tok_j = AutoTokenizer.from_pretrained(name, padding_side="left")
    m = AutoModelForCausalLM.from_pretrained(name, torch_dtype=torch.bfloat16, device_map="auto").eval(); res = {}
    for dname, df in dfs.items():
        rs = list(df.itertuples())
        for v in range(N_VARIANTS):
            for key, (title, rub, digits) in RUBRIC.items():
                ids = [tok_j.encode(str(d), add_special_tokens=False)[0] for d in digits]; w = torch.tensor(list(digits), dtype=torch.float32)
                prompts = [tok_j.apply_chat_template([{"role": "user", "content": judge_prompt(r, key, v)}], tokenize=False, add_generation_prompt=True, enable_thinking=False) for r in rs]
                order = sorted(range(len(prompts)), key=lambda i: len(prompts[i])); vals = [None]*len(prompts); s, b = 0, bs
                while s < len(order):
                    idx = order[s:s+b]
                    try:
                        enc = tok_j([prompts[i] for i in idx], return_tensors="pt", padding=True).to(m.device)
                        h = m.model(**enc).last_hidden_state[:, -1]                    # last position only (saves memory)
                        p = torch.softmax(m.lm_head(h)[:, ids].float(), dim=-1).cpu(); e = (p * w).sum(-1).tolist()
                    except torch.cuda.OutOfMemoryError:
                        gc.collect(); torch.cuda.empty_cache(); b = max(1, b // 2); print("OOM -> judge batch", b, flush=True); continue
                    for j, i in enumerate(idx): vals[i] = e[j]
                    s += len(idx)
                res[f"{dname}|{v}|{key}"] = vals
        print("  judged with", name, flush=True)
    del m; gc.collect(); torch.cuda.empty_cache()
    return res

def get_judge_cache(dfs, cache_path, judges=None, reuse_path=None):
    """Judge scores per model, cached on disk. `dfs` maps a dataset id to a DataFrame; a cached entry is reused only
    if it covers the same dataset id and length (predict.py uses a content hash as the id)."""
    judges = judges or JUDGES
    if not os.path.exists(cache_path) and reuse_path and os.path.exists(reuse_path):
        old = json.load(open(reuse_path)); json.dump({n: v for n, v in old.items() if n in judges}, open(cache_path, "w")); print("reusing cached judge scores for", [n for n in old if n in judges])
    cache = json.load(open(cache_path)) if os.path.exists(cache_path) else {}
    for name in judges:
        have = cache.get(name, {}); need = {k: d for k, d in dfs.items() if f"{k}|{N_VARIANTS-1}|cefr" not in have or len(have[f"{k}|0|cefr"]) != len(d)}
        if need:
            have.update(judge_model_scores(name, need)); cache[name] = have; json.dump(cache, open(cache_path, "w"))
    return cache

def judge_signal(cache, dname, models=None):
    """Mean over judge models x prompt variants, per key; CEFR on the 0-5 index scale."""
    out = {}
    for key in RUBRIC:
        arr = np.mean([cache[n][f"{dname}|{v}|{key}"] for n in (models or JUDGES) for v in range(N_VARIANTS)], axis=0)
        out[key] = arr - 1 if key == "cefr" else arr
    return out



# ================= blend =================
class Normaliser:
    """z-scores with batch statistics (stats=None) or with frozen statistics; every statistic is recorded by name."""
    def __init__(self, stats=None):
        self.stats, self.record = stats, {}

    def _get(self, name, x, ddof):
        x = np.asarray(x, dtype=float)
        if self.stats is not None: m, s = self.stats[name]
        else: m, s = float(np.mean(x)), float(np.std(x, ddof=ddof))
        self.record[name] = [m, s]; return m, s

    def z(self, name, x):
        m, s = self._get(name, x, 0); return (np.asarray(x, dtype=float) - m) / (s + 1e-9)

    def ref(self, name, x):
        """mean / sample std (ddof=1, as pandas) of the encoder's own predictions; used to map blended scores back to 0-5 / 0-4."""
        return self._get(name, x, 1)


def log_words(texts):
    return np.log1p(np.array([len(re.findall(r"\w+", t)) for t in texts], dtype=float))


def as_pred(g, c, ce):
    return pd.DataFrame({"grammar": g, "content": c, "cefr_expected": ce,
                         "cefr_idx": np.clip(np.rint(ce), 0, 5).astype(int)})


def combine(enc, J, texts, w_judge=0.70, len_w=0.20, stats=None):
    """enc: DataFrame with grammar, content, cefr_expected (encoder). J: dict grammar, content, cefr (judge ensemble, CEFR on 0-5).
    texts: the emails (for the length prior). Returns (prediction DataFrame, recorded statistics)."""
    N = Normaliser(stats); wj = w_judge
    g = (1 - wj) * N.z("enc_grammar", enc.grammar) + wj * N.z("judge_grammar", J["grammar"])
    c = (1 - wj) * N.z("enc_content", enc.content) + wj * N.z("judge_content", J["content"])
    if len_w: c = (1 - len_w) * N.z("blend_content", c) + len_w * N.z("log_words", log_words(texts))
    cd = (1 - wj) * np.asarray(enc.cefr_expected, dtype=float) + wj * np.asarray(J["cefr"], dtype=float)
    zg, zc, zcd = N.z("blend_grammar", g), N.z("blend_content_final", c), N.z("cefr_direct", cd)
    mix = 0.5 * zcd + 0.25 * zg + 0.25 * zc
    m, s = N.record["cefr_direct"]                       # mean / std of the direct level signal
    cf = m + s * N.z("cefr_mix", mix)
    mg, sg = N.ref("enc_grammar_ref", enc.grammar); mc, sc = N.ref("enc_content_ref", enc.content)
    grammar = np.clip(mg + sg * zg, 0, 5); content = np.clip(mc + sc * zc, 0, 4)
    return as_pred(grammar, content, cf), N.record


# ================= metrics =================
TARGETS = {"grammar_pearson": .60, "content_pearson": .60, "cefr_pearson": .60, "cefr_exact": .30}
def scores(gg, gc, gl, pg, pc, pl):
    gl, pl = np.asarray(gl), np.asarray(pl)
    return {"grammar_pearson": pearsonr(pg, gg)[0], "content_pearson": pearsonr(pc, gc)[0], "cefr_pearson": pearsonr(pl, gl)[0],
            "cefr_exact": float((pl == gl).mean()), "cefr_within1": float((abs(pl - gl) <= 1).mean())}


# ================= pipeline =================
def read_table(path):
    return pd.read_csv(path, encoding="utf-8") if path.endswith(".csv") else pd.read_excel(path)


def dataset_id(df):
    return "data_" + hashlib.sha1("\n".join(df.text.tolist()).encode("utf-8")).hexdigest()[:12]


def run(df, model_dir, cache_path, judges=None, stats=None):
    df = df.copy(); df["text"] = df.text.astype(str).map(norm)
    if "questionStatement" not in df: df["questionStatement"] = ""
    df["questionStatement"] = df.questionStatement.fillna("").astype(str)
    # 1) encoder with the saved weights
    tok = AutoTokenizer.from_pretrained(model_dir)
    model = MultiTaskModel(config=AutoConfig.from_pretrained(model_dir))
    model.load_state_dict(torch.load(os.path.join(model_dir, "weights.pt"), map_location="cpu"))
    model.to(DEVICE).eval()
    enc = run_eval(model, DS(df[["questionStatement", "text"]], tok))
    del model; gc.collect(); torch.cuda.empty_cache() if DEVICE == "cuda" else None
    # 2) judges (cached on disk)
    judges = judges or JUDGES; did = dataset_id(df)
    cache = get_judge_cache({did: df}, cache_path, judges)
    J = judge_signal(cache, did, judges)
    # 3) blend
    out, rec = combine(enc, J, df.text.tolist(), W_JUDGE, LEN_W, stats)
    out["cefr"] = [CEFR[i] for i in out.cefr_idx]
    return out[["grammar", "content", "cefr", "cefr_idx", "cefr_expected"]], rec


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True); ap.add_argument("--model_dir", required=True)
    ap.add_argument("--output", default="preds.csv"); ap.add_argument("--cache", default="judge_cache.json")
    ap.add_argument("--stats", default=None); ap.add_argument("--save_stats", default=None)
    a = ap.parse_args()
    torch.manual_seed(SEED); np.random.seed(SEED)
    df = read_table(a.input)
    stats = json.load(open(a.stats)) if a.stats else None
    pred, rec = run(df, a.model_dir, a.cache, stats=stats)
    pred.round(4).to_csv(a.output, index=False, encoding="utf-8-sig"); print("wrote", a.output, pred.shape)
    if a.save_stats: json.dump(rec, open(a.save_stats, "w"), indent=1)
    if {"grammar", "content", "cefr"} <= set(df.columns):                   # gold labels present: report the assessment metrics
        gl = df.cefr.astype(str).str.strip().str.upper().map(CEFR.index).values
        s = scores(df.grammar.values, df.content.values, gl, pred.grammar.values, pred.content.values, pred.cefr_idx.values)
        for k, t in TARGETS.items(): print(f"{k:16s} {s[k]:.3f}   target >= {t:.2f}   {'PASS' if s[k] >= t else 'FAIL'}")
        print(f"{'cefr_within1':16s} {s['cefr_within1']:.3f}")
        if "language" in df:
            rows = []
            for l, ix in df.groupby("language").groups.items():
                ix = list(ix); r = scores(df.grammar.values[ix], df.content.values[ix], gl[ix], pred.grammar.values[ix], pred.content.values[ix], pred.cefr_idx.values[ix])
                rows.append({"language": l, "n": len(ix), **{k: round(v, 3) for k, v in r.items()}})
            print(pd.DataFrame(rows).to_string(index=False))
        print(pd.crosstab(pd.Series(gl, name="gold").map(lambda i: CEFR[i]), pred.cefr.rename("pred")).reindex(index=CEFR, columns=CEFR, fill_value=0))
