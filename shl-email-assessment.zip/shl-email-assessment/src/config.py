"""Shared settings. Every value used for the reported run is set here."""
import os, random, unicodedata
import numpy as np, torch

SEED = 42
LANGS = ["Polish", "Italian", "Greek", "Dutch", "Portuguese"]
CEFR = ["A1", "A2", "B1", "B2", "C1", "C2"]

# --- synthetic data generation ---
GEN_MODEL = "Qwen/Qwen2.5-7B-Instruct"     # open model that writes the training emails (bf16)
N_PER_LANG = 500                           # requested emails per language before augmentation
USE_JUDGE = False                          # optional label filter at data-generation time; off in the reported run

# --- encoder ---
BACKBONE = "xlm-roberta-base"
MAX_LEN, BS, EPOCHS, LR = 512, 16, 6, 2e-5
USE_REAL = True                            # add public real learner texts (CEFR labels only)

# --- LLM judges (zero-shot) and final combination ---
JUDGES = ["Qwen/Qwen2.5-14B-Instruct", "Qwen/Qwen3-14B"]
N_VARIANTS = 2                             # prompt variants per judge
W_JUDGE, LEN_W = 0.70, 0.20                # blend weight of the judges; weight of the log-length prior on content

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
OUT = os.environ.get("SHL_OUT", "outputs")  # where models, caches and predictions are written


def seed_everything(seed=SEED):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)


def norm(t):
    """Keep all scripts intact: NFC normalisation, no lossy ASCII folding."""
    return unicodedata.normalize("NFC", t).replace("\r\n", "\n").strip()
