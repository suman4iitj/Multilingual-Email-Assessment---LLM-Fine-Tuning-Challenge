"""Public real learner texts (UniversalCEFR on Hugging Face). CEFR labels only: no grammar or content scores exist for these,
so their grammar/content loss is masked during training. Texts are NOT redistributed in this repository (licences below);
this script downloads them and rebuilds the exact training rows and the real held-out split (fixed seed).

  merlin_it    Italian     CC BY-SA 4.0
  cople2_pt    Portuguese  CC BY-NC-SA 4.0
  peapl2_pt    Portuguese  CC BY-NC-SA 4.0
  elg_cefr_nl  Dutch       CC BY-NC-SA 4.0
Source: https://huggingface.co/UniversalCEFR  (see the corpora's own dataset cards for citation details).
"""
import numpy as np, pandas as pd
from config import SEED, norm

REAL = {"merlin_it": ("Italian", 400), "cople2_pt": ("Portuguese", 300), "peapl2_pt": ("Portuguese", 200), "elg_cefr_nl": ("Dutch", 150)}   # (language, max rows)
LV = {"A1": 0, "A2": 1, "B1": 2, "B2": 3, "C1": 4, "C2": 5}


def load_real(seed=SEED, holdout_frac=0.15, verbose=True):
    """Returns (real_train, real_holdout) DataFrames in the same column layout as data/train_synthetic.csv."""
    from datasets import load_dataset
    rows = []
    for name, (lang, cap) in REAL.items():
        try:
            d = load_dataset(f"UniversalCEFR/{name}")
            d = pd.concat([d[sp].to_pandas() for sp in d.keys()], ignore_index=True)
        except Exception as e:
            print("skip", name, "->", repr(e)[:150]); continue
        d["cefr_idx"] = d.cefr_level.astype(str).str.strip().str.upper().str[:2].map(LV)
        d["text"] = d.text.astype(str).map(norm)
        d = d.dropna(subset=["cefr_idx"]); d = d[d.text.str.split().str.len().between(30, 400)]
        d = d.sample(min(cap, len(d)), random_state=seed)
        lic = d["license"].values if "license" in d else "unknown"
        rows.append(pd.DataFrame({"language": lang, "questionStatement": f"Write an email in {lang}.", "text": d.text.values,
                                  "grammar": np.nan, "content": np.nan, "cefr_idx": d.cefr_idx.astype(int).values,
                                  "scenario_id": "REAL", "aug": "none", "source": name, "license": lic}))
        if verbose: print(f"{name:12s} {len(rows[-1]):4d} rows  levels {rows[-1].cefr_idx.value_counts().sort_index().to_dict()}")
    if not rows: return None, None
    real_df = pd.concat(rows, ignore_index=True)
    hold = real_df.sample(frac=holdout_frac, random_state=seed)
    return real_df.drop(hold.index), hold.reset_index(drop=True)
