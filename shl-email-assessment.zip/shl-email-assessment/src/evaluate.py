"""Metrics used by the assessment: Pearson r for grammar, content and CEFR, CEFR exact match.
  python src/evaluate.py --pred preds.csv --gold test_dataset.xlsx          # predict.py output + gold file (same row order)
  python src/evaluate.py --joined results/test_predictions.csv              # file that already holds gold and p_* columns
Add --bootstrap 2000 for 95% intervals, --by_language and --confusion for the error analysis."""
import argparse
import numpy as np, pandas as pd
from scipy.stats import pearsonr

CEFR = ["A1", "A2", "B1", "B2", "C1", "C2"]
TARGETS = {"grammar_pearson": .60, "content_pearson": .60, "cefr_pearson": .60, "cefr_exact": .30}


def scores(gg, gc, gl, pg, pc, pl):
    gl, pl = np.asarray(gl), np.asarray(pl)
    return {"grammar_pearson": pearsonr(pg, gg)[0], "content_pearson": pearsonr(pc, gc)[0], "cefr_pearson": pearsonr(pl, gl)[0],
            "cefr_exact": float((pl == gl).mean()), "cefr_within1": float((abs(pl - gl) <= 1).mean())}


def load_pairs(a):
    if a.joined:
        d = pd.read_csv(a.joined)
        return d, d.grammar, d.content, d.cefr_idx, d.p_grammar, d.p_content, d.p_cefr_idx
    p, g = pd.read_csv(a.pred), pd.read_excel(a.gold) if a.gold.endswith("xlsx") else pd.read_csv(a.gold)
    gl = g.cefr.str.strip().str.upper().map(CEFR.index)
    pl = p.cefr_idx if "cefr_idx" in p else p.cefr.str.strip().str.upper().map(CEFR.index)
    d = g.assign(cefr_idx=gl, p_cefr_idx=pl.values)
    return d, g.grammar, g.content, gl, p.grammar, p.content, pl


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--pred"); ap.add_argument("--gold"); ap.add_argument("--joined")
    ap.add_argument("--bootstrap", type=int, default=0); ap.add_argument("--by_language", action="store_true"); ap.add_argument("--confusion", action="store_true")
    a = ap.parse_args()
    d, gg, gc, gl, pg, pc, pl = load_pairs(a)
    gg, gc, gl, pg, pc, pl = [np.asarray(x) for x in (gg, gc, gl, pg, pc, pl)]
    s = scores(gg, gc, gl, pg, pc, pl)
    for k, t in TARGETS.items(): print(f"{k:16s} {s[k]:.3f}   target >= {t:.2f}   {'PASS' if s[k] >= t else 'FAIL'}")
    print(f"{'cefr_within1':16s} {s['cefr_within1']:.3f}")
    if a.bootstrap:
        rng = np.random.RandomState(0); n = len(gg); R = []
        for _ in range(a.bootstrap):
            i = rng.randint(0, n, n); r = scores(gg[i], gc[i], gl[i], pg[i], pc[i], pl[i]); R.append([r[k] for k in TARGETS])
        R = np.array(R); lo, hi = np.percentile(R, [2.5, 97.5], axis=0)
        for j, k in enumerate(TARGETS): print(f"  95% bootstrap interval {k:16s} [{lo[j]:.3f}, {hi[j]:.3f}]")
    if a.by_language and "language" in d:
        rows = []
        for l, x in d.assign(pg=pg, pc=pc, pl=pl, gg=gg, gc=gc, gl=gl).groupby("language"):
            r = scores(x.gg, x.gc, x.gl, x.pg, x.pc, x.pl); rows.append({"language": l, "n": len(x), **{k: round(v, 3) for k, v in r.items()}})
        print(pd.DataFrame(rows).to_string(index=False))
    if a.confusion:
        print(pd.crosstab(pd.Series(gl, name="gold").map(lambda i: CEFR[i]), pd.Series(pl, name="pred").map(lambda i: CEFR[i])).reindex(index=CEFR, columns=CEFR, fill_value=0))
