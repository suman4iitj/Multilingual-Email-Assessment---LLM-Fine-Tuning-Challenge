"""Multitask multilingual email assessor: grammar (0-5), content (0-4), CEFR (A1-C2, ordinal)."""
import torch, torch.nn as nn
from transformers import AutoModel

CEFR_LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"]
G_MAX, C_MAX = 5.0, 4.0


class MultiTaskModel(nn.Module):
    def __init__(self, name=None, config=None, dropout=0.1):
        super().__init__()
        self.enc = AutoModel.from_pretrained(name) if config is None else AutoModel.from_config(config)
        h = self.enc.config.hidden_size
        self.drop = nn.Dropout(dropout)
        self.g_head = nn.Sequential(nn.Linear(h, h // 2), nn.GELU(), nn.Linear(h // 2, 1))
        self.c_head = nn.Sequential(nn.Linear(h, h // 2), nn.GELU(), nn.Linear(h // 2, 1))
        # CORAL-style ordinal head: one shared score + 5 ordered thresholds. Sees the pooled text
        # plus the (detached) grammar/content predictions as extra signals.
        self.cefr_fc = nn.Linear(h + 2, 1, bias=False)
        self.cefr_bias = nn.Parameter(torch.linspace(1.5, -1.5, 5))

    def forward(self, input_ids, attention_mask, **_):
        hs = self.enc(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        m = attention_mask.unsqueeze(-1).to(hs.dtype)
        pooled = self.drop((hs * m).sum(1) / m.sum(1).clamp(min=1))  # masked mean pooling
        g = self.g_head(pooled).squeeze(-1)   # normalised 0..1
        c = self.c_head(pooled).squeeze(-1)
        x = torch.cat([pooled, g.detach().unsqueeze(-1), c.detach().unsqueeze(-1)], -1)
        cefr_logits = self.cefr_fc(x) + self.cefr_bias  # (B,5): logit of P(level > k)
        return g, c, cefr_logits


def decode(g, c, cefr_logits):
    p = torch.sigmoid(cefr_logits.float())
    return {
        "grammar": (g.float().clamp(0, 1) * G_MAX).cpu().numpy(),
        "content": (c.float().clamp(0, 1) * C_MAX).cpu().numpy(),
        "cefr_idx": (p > 0.5).sum(1).cpu().numpy(),      # discrete level for exact match
        "cefr_expected": p.sum(1).cpu().numpy(),          # continuous level
    }
