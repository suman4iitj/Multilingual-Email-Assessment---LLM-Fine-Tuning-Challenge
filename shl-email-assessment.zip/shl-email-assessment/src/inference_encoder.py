"""Encoder-only inference (the fine-tuned model without the LLM judges). Usage: python src/inference_encoder.py --model_dir outputs/model --input emails.csv --output preds.csv
CSV needs a `text` column (optional `questionStatement`). Reads/writes UTF-8."""
import argparse, os, sys, pandas as pd, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from transformers import AutoTokenizer, AutoConfig
from model import MultiTaskModel, decode, CEFR_LEVELS


def load(model_dir, device=None):
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    tok = AutoTokenizer.from_pretrained(model_dir)
    model = MultiTaskModel(config=AutoConfig.from_pretrained(model_dir))
    model.load_state_dict(torch.load(os.path.join(model_dir, "weights.pt"), map_location="cpu"))
    return tok, model.to(device).eval(), device


@torch.no_grad()
def predict(df, tok, model, device, max_len=512, bs=16):
    q = df["questionStatement"].fillna("").astype(str).tolist() if "questionStatement" in df else [""] * len(df)
    t = df["text"].fillna("").astype(str).tolist()
    out = []
    for i in range(0, len(t), bs):
        enc = tok(q[i:i+bs], t[i:i+bs], truncation=True, max_length=max_len, padding=True, return_tensors="pt").to(device)
        out.append(pd.DataFrame(decode(*model(**enc))))
    r = pd.concat(out, ignore_index=True)
    r["cefr"] = [CEFR_LEVELS[i] for i in r.cefr_idx]
    return r


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--model_dir", required=True)
    ap.add_argument("--input", required=True); ap.add_argument("--output", default="preds.csv")
    a = ap.parse_args()
    df = pd.read_csv(a.input, encoding="utf-8") if a.input.endswith(".csv") else pd.read_excel(a.input)
    tok, model, dev = load(a.model_dir)
    predict(df, tok, model, dev).to_csv(a.output, index=False, encoding="utf-8-sig")
