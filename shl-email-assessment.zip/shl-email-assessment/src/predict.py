"""Full inference pipeline: fine-tuned encoder + two zero-shot LLM judges + fixed-weight combination.

  python src/predict.py --input test_dataset.xlsx --model_dir outputs/model --output preds.csv

Input : csv/xlsx with `text` (required), `questionStatement` and `language` (recommended, the judges use them).
Output: csv with grammar (0-5), content (0-4), cefr (A1..C2), cefr_idx (0..5), cefr_expected.

Standardisation inside the blend uses the statistics of the scored batch (as in the reported run on the 309 test emails).
For small batches use frozen statistics: first run once on a reference batch with --save_stats stats.json, later runs with --stats stats.json.
Judge scores are cached per dataset (content hash), so a second run on the same file skips the LLMs.
Memory: each 14B judge needs ~30 GB in bf16 (one A100 40 GB is enough; judges are loaded one after the other).
"""
import argparse, hashlib, json, os, sys
import numpy as np, pandas as pd, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from transformers import AutoTokenizer, AutoConfig
from config import *
from model import MultiTaskModel
from train_encoder import DS, run_eval
from judge import get_judge_cache, judge_signal
from combine import combine, CEFR_LEVELS


def read_table(path):
    return pd.read_csv(path, encoding="utf-8") if path.endswith(".csv") else pd.read_excel(path)


def dataset_id(df):
    return "data_" + hashlib.sha1("\n".join(df.text.tolist()).encode("utf-8")).hexdigest()[:12]


def load_encoder(model_dir):
    tok = AutoTokenizer.from_pretrained(model_dir)
    model = MultiTaskModel(config=AutoConfig.from_pretrained(model_dir))
    model.load_state_dict(torch.load(os.path.join(model_dir, "weights.pt"), map_location="cpu"))
    return tok, model.to(DEVICE).eval()


def run(df, model_dir, judges=None, cache_path=None, stats=None, w_judge=W_JUDGE, len_w=LEN_W, encoder_only=False):
    """Returns (predictions DataFrame, recorded normalisation statistics or None)."""
    df = df.copy(); df["text"] = df.text.astype(str).map(norm)
    if "questionStatement" not in df: df["questionStatement"] = ""
    df["questionStatement"] = df.questionStatement.fillna("").astype(str)
    tok, model = load_encoder(model_dir)
    enc = run_eval(model, DS(df[["questionStatement", "text"]], tok))
    del model
    if encoder_only:
        out = enc[["grammar", "content", "cefr_idx", "cefr_expected"]].copy(); rec = None
    else:
        did = dataset_id(df); judges = judges or JUDGES
        cache = get_judge_cache({did: df}, cache_path or os.path.join(OUT, "judge_cache.json"), judges)
        J = judge_signal(cache, did, judges)
        out, rec = combine(enc, J, df.text.tolist(), w_judge, len_w, stats)
    out["cefr"] = [CEFR_LEVELS[i] for i in out.cefr_idx]
    return out[["grammar", "content", "cefr", "cefr_idx", "cefr_expected"]], rec


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True); ap.add_argument("--output", default="preds.csv")
    ap.add_argument("--model_dir", default=os.path.join(OUT, "model")); ap.add_argument("--cache", default=None)
    ap.add_argument("--stats", default=None, help="frozen normalisation statistics (json) for small batches")
    ap.add_argument("--save_stats", default=None, help="write the normalisation statistics of this batch to json")
    ap.add_argument("--encoder_only", action="store_true", help="skip the LLM judges (fast, lower accuracy)")
    ap.add_argument("--w_judge", type=float, default=W_JUDGE); ap.add_argument("--len_w", type=float, default=LEN_W)
    a = ap.parse_args(); seed_everything()
    df = read_table(a.input)
    stats = json.load(open(a.stats)) if a.stats else None
    if stats is None and not a.encoder_only and len(df) < 50:
        print("WARNING: fewer than 50 emails and no --stats: batch statistics are unreliable, see the README.")
    pred, rec = run(df, a.model_dir, cache_path=a.cache, stats=stats, w_judge=a.w_judge, len_w=a.len_w, encoder_only=a.encoder_only)
    pred.round(4).to_csv(a.output, index=False, encoding="utf-8-sig"); print("wrote", a.output, pred.shape)
    if a.save_stats and rec is not None: json.dump(rec, open(a.save_stats, "w"), indent=1); print("saved statistics ->", a.save_stats)
